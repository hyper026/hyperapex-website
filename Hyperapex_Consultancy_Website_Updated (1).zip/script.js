const menuToggle = document.querySelector(".menu-toggle");
const navLinks = document.querySelector(".nav-links");

menuToggle.addEventListener("click", () => {
  const open = navLinks.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", open);
});

document.querySelectorAll(".nav-links a").forEach(link => {
  link.addEventListener("click", () => {
    navLinks.classList.remove("open");
    menuToggle.setAttribute("aria-expanded", "false");
  });
});

document.getElementById("year").textContent = new Date().getFullYear();

const form = document.getElementById("contactForm");
const status = document.getElementById("formStatus");

form.addEventListener("submit", (event) => {
  event.preventDefault();

  const data = new FormData(form);
  const name = data.get("name");
  const company = data.get("company");
  const email = data.get("email");
  const phone = data.get("phone");
  const service = data.get("service");
  const message = data.get("message");

  const subject = encodeURIComponent(`Website enquiry - ${service}`);
  const body = encodeURIComponent(
`Dear Hyperapex Consultancy Firm Limited,

I would like to make an enquiry.

Name: ${name}
Company / Organization: ${company || "N/A"}
Email: ${email}
Phone: ${phone}
Service Required: ${service}

Message:
${message}

Kind regards,
${name}`
  );

  window.location.href = `mailto:info@hyperapex.co.ke?subject=${subject}&body=${body}`;
  status.textContent = "Your email application should now open with the enquiry prepared.";
});
