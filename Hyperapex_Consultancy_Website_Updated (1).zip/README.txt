HYPERAPEX CONSULTANCY FIRM LIMITED - WEBSITE

Files:
- index.html
- styles.css
- script.js

SETUP:
1. Open index.html in a browser to preview the website.
2. Official telephone/WhatsApp: +254 719 682 640.
3. Official email: hyperapexconsult@gmail.com.
4. Update the postal address if required.
5. WhatsApp is configured for +254 719 682 640.
6. Add the official company logo if available.

CONTACT FORM:
The form currently uses a mailto link, so it does not require a server. For a fully managed website contact form that stores enquiries or sends them automatically, connect the form to a backend or form service before launch.

DEPLOYMENT:
This is a responsive static website and can be deployed to any standard web host or static hosting platform. Upload all three files to the public web directory.

RECOMMENDED PRE-LAUNCH:
- Add the official logo and favicon.
- Add verified company contact details.
- Add the physical office address.
- Add official social media links if available.
- Add a privacy policy and terms page if collecting personal data.
- Connect the contact form to a secure server-side email service.
